// Importa API para manipular arquivos do sistema (ler e salvar dados)
import fs from 'fs/promises';

// Importa as classes que definem as entidades do sistema
import Funcionario from '../models/Funcionario.js';
import Departamento from '../models/Departamento.js';

// Classe que gerencia listas de funcionários e departamentos, e todas as operações
class GerenciadorFuncionarios {
  constructor() {
    this.funcionarios = [];  // Lista interna para guardar os funcionários
    this.departamentos = []; // Lista interna para guardar os departamentos
  }

  // Função para adicionar um funcionário na lista
  adicionarFuncionario(func) {
    func.validar(); // valida os dados para evitar erros
    // Verifica se funcionário com mesmo ID já existe
    if (this.buscarFuncionarioPorId(func.id)) {
      throw new Error('Funcionário com este ID já existe.');
    }
    this.funcionarios.push(func); // adiciona na lista
  }

  // Retorna a lista de todos os funcionários
  listarFuncionarios() {
    return this.funcionarios;
  }

  // Busca funcionário pelo ID, retorna o funcionário ou undefined
  buscarFuncionarioPorId(id) {
    return this.funcionarios.find(f => f.id === id);
  }

  // Atualiza os dados do funcionário com o ID informado
  atualizarFuncionario(id, novosDados) {
    const func = this.buscarFuncionarioPorId(id);
    if (!func) throw new Error('Funcionário não encontrado.');
    Object.assign(func, novosDados); // atualiza propriedades
    func.validar(); // valida os dados atualizados
  }

  // Remove um funcionário da lista pelo ID
  removerFuncionario(id) {
    const index = this.funcionarios.findIndex(f => f.id === id);
    if (index === -1) throw new Error('Funcionário não encontrado.');
    this.funcionarios.splice(index, 1); // remove da lista
  }

  // Adiciona um departamento à lista com validação similar
  adicionarDepartamento(dept) {
    dept.validar();
    if (this.buscarDepartamentoPorId(dept.id)) {
      throw new Error('Departamento com este ID já existe.');
    }
    this.departamentos.push(dept);
  }

  // Retorna lista de departamentos
  listarDepartamentos() {
    return this.departamentos;
  }

  // Busca departamento pelo ID
  buscarDepartamentoPorId(id) {
    return this.departamentos.find(d => d.id === id);
  }

  // Atualiza dados do departamento pelo ID
  atualizarDepartamento(id, novosDados) {
    const dept = this.buscarDepartamentoPorId(id);
    if (!dept) throw new Error('Departamento não encontrado.');
    Object.assign(dept, novosDados);
    dept.validar();
  }

  // Remove departamento e unlink funcionários do departamento removido
  removerDepartamento(id) {
    const index = this.departamentos.findIndex(d => d.id === id);
    if (index === -1) throw new Error('Departamento não encontrado.');
    // Remove associação de funcionários ao departamento removido
    this.funcionarios.forEach(f => {
      if (f.departamentoId === id) f.removerDepartamento();
    });
    this.departamentos.splice(index, 1);
  }

  // Liga um funcionário a um departamento
  atribuirFuncionarioADepartamento(idFuncionario, idDepartamento) {
    const func = this.buscarFuncionarioPorId(idFuncionario);
    const dept = this.buscarDepartamentoPorId(idDepartamento);
    if (!func) throw new Error('Funcionário não encontrado.');
    if (!dept) throw new Error('Departamento não encontrado.');
    func.atribuirDepartamento(idDepartamento); // Atualiza o funcionário
  }

  // Salva as listas em arquivos JSON para persistência dos dados
  async salvarParaArquivo(caminhoArquivoFuncionarios, caminhoArquivoDepartamentos) {
    await fs.writeFile(caminhoArquivoFuncionarios, JSON.stringify(this.funcionarios, null, 2), 'utf8');
    await fs.writeFile(caminhoArquivoDepartamentos, JSON.stringify(this.departamentos, null, 2), 'utf8');
  }

  // Carrega listas de arquivos JSON, se existirem
  async carregarDeArquivo(caminhoArquivoFuncionarios, caminhoArquivoDepartamentos) {
    try {
      const dadosFuncs = await fs.readFile(caminhoArquivoFuncionarios, 'utf8');
      const listaFuncs = JSON.parse(dadosFuncs);
      // Converte os dados JSON para objetos da classe Funcionario
      this.funcionarios = listaFuncs.map(f => {
        const func = new Funcionario(f.id, f.nome, f.cargo, f.salario, f.ativo);
        func.departamentoId = f.departamentoId ?? null;
        return func;
      });
    } catch (error) {
      if (error.code === 'ENOENT') this.funcionarios = []; // Arquivo não existe, lista vazia.
      
      else throw error; // Outros erros: relêvante para debugar
    }

    try {
      const dadosDepts = await fs.readFile(caminhoArquivoDepartamentos, 'utf8');
      const listaDepts = JSON.parse(dadosDepts);
      this.departamentos = listaDepts.map(d => new Departamento(d.id, d.nome));
    } catch (error) {
      if (error.code === 'ENOENT') this.departamentos = [];
      else throw error;
    }
  }
}

// Exporta a classe para o código principal usar
export default GerenciadorFuncionarios;
